#!/bin/sh
ICAROOT=/usr/lib/ICAClient 
export ICAROOT
$ICAROOT/wfica -associate -fileparam $1
