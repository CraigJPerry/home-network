#!/bin/sh
ICAROOT=/usr/lib/ICAClient 
export ICAROOT
$ICAROOT/wfica -file $1
